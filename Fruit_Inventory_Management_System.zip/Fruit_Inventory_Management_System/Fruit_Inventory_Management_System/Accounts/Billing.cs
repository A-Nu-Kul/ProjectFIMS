﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using MySql.Data.MySqlClient;

namespace Fruit_Inventory_Management_System.Accounts
{
    public partial class Billing : Form
    {
        public Billing()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnView_Click(object sender, EventArgs e)
        {
            string myConnection = "datasource=localhost;port=3306;username=root;password=root";
            MySqlConnection myConn = new MySqlConnection(myConnection);
            MySqlCommand command = new MySqlCommand();
            command.Connection = myConn;
            command.CommandText = "select * from  fims.sales";
            DataTable data = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            adapter.Fill(data);
            dataGridView1.DataSource = data;
        }
        private void myPrintDocument1_PrintPage(System.Object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            Bitmap myBitmap1 = new Bitmap(panel1.Width, panel1.Height);

            panel1.DrawToBitmap(myBitmap1, new Rectangle(0, 0, panel1.Width, panel1.Height));

            e.Graphics.DrawImage(myBitmap1, 0, 0);

            myBitmap1.Dispose();

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            System.Drawing.Printing.PrintDocument myPrintDocument1 = new System.Drawing.Printing.PrintDocument();

            PrintDialog myPrinDialog1 = new PrintDialog();

            myPrintDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(myPrintDocument1_PrintPage);

            myPrinDialog1.Document = myPrintDocument1;



            if (myPrinDialog1.ShowDialog() == DialogResult.OK)
            {

                myPrintDocument1.Print();

            }
        }

            private void timer1_Tick(object sender, EventArgs e)
            {
                lblTime.Text = DateTime.Now.ToShortTimeString();

            }

            private void Billing_Load(object sender, EventArgs e)
            {
                lblDate.Text = DateTime.Now.ToShortDateString();
            }
        }
    }

