﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fruit_Inventory_Management_System
{
    public partial class Main_Form : Form
    {
        public Main_Form()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void newStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Stock.NewStock().Show();
        }

        private void viewStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Stock.StockViewAll().Show();
        }

        private void newSalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Sales.NewSales().Show();
        }

        private void viewSalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Sales.SalesViewAll().Show();
        }

        private void salesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new Report.DailySalesReport().Show();
        }

        private void stockToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new Report.DailyStockReport().Show();
        }

        private void salesToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            new Report.MonthlySalesReport().Show();
        }

        private void stockToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            new Report.MonthlyStockReport().Show();
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc.exe");
        }

        private void notepadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Notepad.exe");
        }

        private void wordpadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Wordpad.exe");
        }

        private void taskManagerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("TaskMgr.exe");
        }

        private void msWordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Winword.exe");
        }

        private void billingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Accounts.Billing().ShowDialog();
        }

        private void aboutUsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new AboutUs().ShowDialog();
        }
    }
}
