﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fruit_Inventory_Management_System.Sales
{
    public partial class NewSales : Form
    {
        public NewSales()
        {
            InitializeComponent();
        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double val1 = 0;
                int val2 = 0;
                double.TryParse(txtRate.Text, out val1);
                int.TryParse(txtQty.Text, out val2);
                double I = (val1 * val2);
                txtAmount.Text = I.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void txtDiscountAmt_TextChanged(object sender, EventArgs e)
        {

            try
            {
                double val3 = 0;
                int val4 = 0;
                double.TryParse(txtAmount.Text, out val3);
                int.TryParse(txtDiscountAmt.Text, out val4);
                double I = (val3 - val4);
                txtGrandTotal.Text = I.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            validation.IsQuantity(e);
        }

        private void txtDiscountAmt_KeyPress(object sender, KeyPressEventArgs e)
        {
            validation.IsInteger(e);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtStockID.Text != "")
            {
                try
                {
                    string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                    MySqlConnection myConn = new MySqlConnection(myConnection);
                    MySqlCommand SelectCommand = new MySqlCommand("select * from fims.stock where Stock_ID ='" + this.txtStockID.Text + "'", myConn);
                    MySqlDataAdapter adp = new MySqlDataAdapter();
                    adp.SelectCommand = SelectCommand;
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    // now get the values
                    this.txtStockName.Text = dt.Rows[0][1].ToString();
                   this.txtRate.Text = dt.Rows[0][2].ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.txtSalesID.Text != "")
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                string dt = dateTime_Date.Text;
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand SelectCommand = new MySqlCommand("insert into fims.sales(Sales_ID,Stock_ID,Stock_Name,Rate,Qty,Amount,Discount_Amount,Grand_Total,Date)values('" + txtSalesID.Text + "','" + txtStockID.Text + "','" + txtStockName.Text + "','" + txtRate.Text + "','" + txtQty.Text + "','" + txtAmount.Text + "','" + txtDiscountAmt.Text + "','" + txtGrandTotal.Text + "','" + dateTime_Date.Text + "')", myConn);
                try
                {
                    myConn.Open();
                    SelectCommand.ExecuteNonQuery();
                }
                catch (MySqlException ex) { throw ex; }
                finally { myConn.Close(); }
                MessageBox.Show("Congratulations!!!, Your Data is Saved");
            }

            else
            {
                MessageBox.Show("Enter All the Fields");
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            foreach (Control b in Controls)
            {
                txtStockID.Text = "";
                txtStockName.Text = "";
                txtRate.Text = "";
                txtSalesID.Text = "";
                txtQty.Text = "";
                txtAmount.Text="";
                txtDiscountAmt.Text = "";
                txtGrandTotal.Text = "";
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (txtSalesID.Text != "")
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                string dt = dateTime_Date.Text;
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand SelectCommand = new MySqlCommand("update fims.sales set  Qty='" + this.txtQty.Text + "',Discount_Amount='" + this.txtDiscountAmt.Text + "',Date='" + this.dateTime_Date.Text + "'", myConn);
                try
                {
                    myConn.Open();
                    SelectCommand.ExecuteNonQuery();
                }
                catch (MySqlException ex) { throw ex; }
                finally { myConn.Close(); }
                MessageBox.Show("Data is Updated");
                this.Refresh();


            }
            else
            {
                MessageBox.Show("Enter All the Fields");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string myConnection = "datasource=localhost;port=3306;username=root;password=root";
            MySqlConnection myConn = new MySqlConnection(myConnection);
            MySqlCommand SelectCommand = new MySqlCommand("delete  from  fims.sales  WHERE        (Sales_ID = '" + this.txtSalesID.Text + "')", myConn);
            myConn.Open();
            SelectCommand.ExecuteNonQuery();
            myConn.Close();
            MessageBox.Show("your data is Deleted");
            this.Refresh();
        }
    }
}


