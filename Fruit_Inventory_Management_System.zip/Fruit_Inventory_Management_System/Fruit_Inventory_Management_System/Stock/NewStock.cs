﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Fruit_Inventory_Management_System.Stock
{
    public partial class NewStock : Form
    {
        public NewStock()
        {
            InitializeComponent();
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            validation.IsAlpha(e);
        }

        private void txtRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            validation.IsInteger(e);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.txtStockID.Text != "")
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand SelectCommand = new MySqlCommand("insert into fims.stock(Stock_ID,Stock_Name,Rate)values('" + txtStockID.Text + "','" + txtName.Text + "','" + txtRate.Text + "')", myConn);
                try
                {
                    myConn.Open();
                    SelectCommand.ExecuteNonQuery();
                }
                catch (MySqlException ex) { throw ex; }
                finally { myConn.Close(); }
                MessageBox.Show("Congratulations!!!, Your Data is Saved");
            }

            else
            {
                MessageBox.Show("Enter All the Fields");
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            foreach (Control b in Controls)
            {
                txtStockID.Text = "";
                txtName.Text = "";
                txtRate.Text = "";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string myConnection = "datasource=localhost;port=3306;username=root;password=root";
            MySqlConnection myConn = new MySqlConnection(myConnection);
            MySqlCommand SelectCommand = new MySqlCommand("delete  from  fims.stock  WHERE        (Sales_ID = '" + this.txtStockID.Text + "')", myConn);
            myConn.Open();
            SelectCommand.ExecuteNonQuery();
            myConn.Close();
            MessageBox.Show("your data is Deleted");
            this.Refresh();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (txtStockID.Text != "")
            {
                string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand SelectCommand = new MySqlCommand("update fims.stock set  Stock_Name='" + this.txtName.Text + "',Rate='" + this.txtRate.Text + "'", myConn);
                try
                {
                    myConn.Open();
                    SelectCommand.ExecuteNonQuery();
                }
                catch (MySqlException ex) { throw ex; }
                finally { myConn.Close(); }
                MessageBox.Show("Data is Updated");
                this.Refresh();


            }
            else
            {
                MessageBox.Show("Enter All the Fields");
            }

        }

        private void btnView_Click(object sender, EventArgs e)
        {
            if (txtStockID.Text != "")
            {
                try
                {
                    string myConnection = "datasource=localhost;port=3306;username=root;password=root";
                    MySqlConnection myConn = new MySqlConnection(myConnection);
                    MySqlCommand SelectCommand = new MySqlCommand("select * from fims.stock where Stock_ID ='" + this.txtStockID.Text + "'", myConn);
                    MySqlDataAdapter adp = new MySqlDataAdapter();
                    adp.SelectCommand = SelectCommand;
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    // now get the values
                    this.txtName.Text = dt.Rows[0][1].ToString();
                    this.txtRate.Text = dt.Rows[0][2].ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}

